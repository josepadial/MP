#include "lista.h"
#include <iostream>
#include "Random.h"


using namespace std;


void LeeLista (Lista & l){
	PNodo p; // puntero para recorrer la lista 
	double  dato; // datos leidos
	
	LiberaLista(l); //si la lista tenía datos hay que liberarlos
	/* 
	NOTA: Esta función es muy específica para resolver el problema planteado
	Sólo funciona si el TipoBase de Lista es un tipo numérico simple. 
	Sólo lee mientras el número no sea negativo
	*/
	
	cin >> dato; //lectura adelantada
	while(dato >= 0){ // si no es negativo
		if (ListaVacia(l)){ // primer dato
			l = new Nodo; // se crea la lista con un único Nodo
			l->valor = dato; // se rellena el nodo
			l->siguiente = 0;
			p = l; // puntero para recorrer la lista
		}else { // resto de los datos
			p->siguiente = new Nodo; // se crea el siguiente Nodo
			p = p-> siguiente; // se avanza el puntero
			p->valor = dato; // se rellena el Nodo
			p->siguiente = 0;
		}
		cin >> dato; // siguiente lectura
	}
}

void PintaLista (const Lista l){
	PNodo p = l; // puntero para recorrer la lista
	while (p != 0){ // mientras haya elementos que recorrer
		cout << p->valor << " "; // pintar el elemento actual
		p = p->siguiente; // avanzar al siguiente elemento
	}
}

void LiberaLista (Lista & l){
	while (l != 0){ // mientras haya elementos en la lista
		PNodo sig = l->siguiente; // guardar la posición del siguiente elemento
		delete l; // borrar el elemento actual
		l = sig; // hacer que la lista empiece en el siguiente elemento
	}
	//Nótese que aquí l es igual a 0 y por tanto la lista está vacia
}

bool ListaVacia (const Lista l){
	return l==0;
}

void RellenaListaAleatoriamente (Lista & l, int num_datos, int min, int max){
	LiberaLista(l); //si la lista tenía datos hay que liberarlos
	/* 
	NOTA: Esta función es muy específica para resolver el problema planteado
	Sólo funciona si el TipoBase de Lista es un tipo numérico simple. 
	*/	
	if (num_datos > 0){ // tengo que meter datos?
		MyRandom aleatorio(min,max); // iniciar generador
		l = new Nodo; // se crea la lista con un único Nodo
		l->valor = aleatorio.Siguiente(); // se rellena el nodo
		l->siguiente = 0;
		PNodo p = l; // puntero para recorrer la lista
		for(int i = 1; i < num_datos; i++){ //Nótese que empieza con i=1 porque el primer dato ya lo hemos metido
			p->siguiente = new Nodo; // se crea el siguiente Nodo
			p->siguiente->valor = aleatorio.Siguiente(); // se rellena el siguiente Nodo
			p->siguiente->siguiente = 0;
			p = p-> siguiente; // se avanza el puntero
		}
	}
}


