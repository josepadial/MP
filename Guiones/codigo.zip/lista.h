/**
@file 
@brief Clase para la estructura de datos de lista de TipoBase

@author Escriba aquí sus nombres, apellidos y DNI
*/
  
#ifndef _LISTA_H_
#define _LISTA_H_

/**
@brief Tipo de los elementos de la lista

Bastará cambiar el tipo asociado al alias TipoBase
y recompilar para poder gestionar otro tipo de lista.
*/
typedef double TipoBase;

/// @brief Tipo de cada nodo de la lista
struct Nodo {
  TipoBase valor;  ///< valor del elemento en el nodo
  Nodo *siguiente; ///< puntero al siguiente elemento de la lista
};

typedef Nodo * PNodo; ///< Tipo de los punteros a nodos
typedef Nodo * Lista; ///< Tipo de la lista. La declaración debe inicializar la lista a 0. p.e. @c Lista l = 0;

/**
@brief Construye una lista enlazadas a partir de la información leida desde el teclado.
@param l lista donde leer los valores

Lee desde el teclado una secuencia con un número indefinido de valores @c double hasta que se introduzca un valor negativo. Estos valores (excepto el último, el negativo)
los almacenará en la  estructura de celdas enlazadas
*/

void LeeLista (Lista & l);

/** 
@brief Escribe en pantalla los valores de una lista
@param l la lista a escribir en pantalla

Muestra en pantalla los valores contenidos en la lista separados por espacio
*/

void PintaLista (const Lista l);

/**
@brief Libera la memoria reservada en la lista
@param l lista a liberar

Libera la memoria reservada y devuelve la lista vacia (l=0).
*/

void LiberaLista (Lista & l);


/**
@brief Comprueba si una lista está vacia
@param l lista a comprobar 
@retval true si la lista está vacia
@retval false si la lista no está vacia

Comprueba si la lista está vacia y devuelve el resultado (@c true o @c false)
*/

bool ListaVacia (const Lista l);

/**
@brief Rellena la lista con valores aleatorios
@param l         lista a rellenar
@param num_datos número de valores aleatorios a insertar en la lista
@param min       valor mínimo de los valores aleatorios a generar
@param max       valor máximo de los valores aleatorios a generar

Rellena la lista @a l con @a num_datos aleatorios en el intervalo [@a min, @a max]
*/

void RellenaListaAleatoriamente (Lista & l, int num_datos, int min, int max);


#endif

