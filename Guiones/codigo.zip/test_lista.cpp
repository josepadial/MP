#include "lista.h"
#include<iostream>

using namespace std;

int main(){
	Lista l = 0; // IMPORTANTE: Inicializar siempre la lista a 0
	
	RellenaListaAleatoriamente(l, 10, 1, 10);
	cout << "Mostrando " << 10 << " valores aleatorios ";
	PintaLista(l);
	cout << "\n\nIntroduce valores positivos (negativo para terminar):\n";
	LeeLista(l);
	cout << "\n\nLos valores leidos son: ";
	PintaLista(l);
	LiberaLista(l);
	cout << endl;
}